package utilities;

@SuppressWarnings("serial")
public class BufferVuotoException extends ArrayIndexOutOfBoundsException {

	public BufferVuotoException(String msg) {
		super(msg);
	}
	
	public BufferVuotoException() {}
	
}
